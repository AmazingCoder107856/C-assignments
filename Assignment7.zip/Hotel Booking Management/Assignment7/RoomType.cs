﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment7
{
    public enum RoomType
    {
        Conference_Room,
        Single_Room,
        Double_Room,
        Twin_Bedded_Room,
        Interconnected_Room,
        Triple_Room,
        Quad,
        Double_Double_Room,
        Suite
    }
}
